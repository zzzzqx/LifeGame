package LifeGame;

import javax.swing.JPanel;

public class Cell {
	
	//ϸ�����ĳ��Ϳ�
	public  int RoomLength ;
	public  int RoomWidth ;
	
	//��¼ϸ����������״ 0���� 1���
	boolean[][] CellRoom ;
	
	public Cell(int length,int width) {
		this.RoomLength = length;
		this.RoomWidth = width;
		CellRoom = new boolean[RoomLength][RoomWidth];
	}
	
	//ϸ��������״̬��������
	public void transform() {
		
		boolean[][] NewCellRoom = new boolean[RoomLength][RoomWidth];
		int Neighbors = 0;
		for(int i=0;i<RoomLength;i++) {
			for(int j=0;j<RoomWidth;j++) {
				Neighbors = 0;
				//��ϸ����Χ����ھ���
				if(i>=1 && j>=1 && CellRoom[i-1][j-1])
					Neighbors++;
				if(i>=1 && CellRoom[i-1][j])
					Neighbors++;
				if(i>=1 && j<RoomWidth-1 && CellRoom[i-1][j+1])
					Neighbors++;
				if(j>=1 && CellRoom[i][j-1])
					Neighbors++;
				if(j<RoomWidth-1 && CellRoom[i][j+1])
					Neighbors++;
				if(i<RoomLength-1 && j>=1 && CellRoom[i+1][j-1])
					Neighbors++;
				if(i<RoomLength-1 && CellRoom[i+1][j])
					Neighbors++;
				if(i<RoomLength-1 && j<RoomWidth-1 && CellRoom[i+1][j+1])
					Neighbors++;
				//�������涨�ɼ���
				if(Neighbors<=1 || Neighbors >= 4)
					NewCellRoom[i][j] = false;
				else if(Neighbors == 3)
					NewCellRoom[i][j] = true ;
				else if(Neighbors == 2)
					NewCellRoom[i][j] = CellRoom[i][j];
					
			}
		}
		//�����ֵ
		for(int i=0;i<RoomLength;i++) 
			for(int j=0;j<RoomWidth;j++)
				CellRoom[i][j] = NewCellRoom[i][j];
		
	}
	
	//��ʼ��ϸ����
	public void Creat() {
		for(int i=0;i<RoomLength;i++) {
			for(int j=0;j<RoomWidth;j++) {
				if((int)(Math.random()*100)>50)
					CellRoom[i][j] = true;
				else {
					CellRoom[i][j] = false;
				}
			}
		}
	}
	
	
	


	
}
