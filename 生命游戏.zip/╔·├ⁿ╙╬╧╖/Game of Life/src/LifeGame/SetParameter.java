package LifeGame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class SetParameter extends JFrame {

	private JPanel contentPane;
	private JTextField textLength;
	private JTextField textWidth;
	private JTextField textSpeed;
	
	/*��¼����*/
	//ϸ������
	private int Length;
	//ϸ������
	private int Width;
	//ϸ�������ٶ�
	private int Speed;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SetParameter frame = new SetParameter();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SetParameter() {
		setBackground(Color.LIGHT_GRAY);
		setTitle("\u7EC6\u80DE\u623F\u53C2\u6570\u8BBE\u7F6E");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		textLength = new JTextField();
		textLength.setBounds(176, 40, 99, 31);
		panel.add(textLength);
		textLength.setColumns(10);
		
		textWidth = new JTextField();
		textWidth.setBounds(176, 94, 99, 31);
		panel.add(textWidth);
		textWidth.setColumns(10);
		
		textSpeed = new JTextField();
		textSpeed.setBounds(176, 147, 99, 31);
		panel.add(textSpeed);
		textSpeed.setColumns(10);
		
		JLabel lblcm = new JLabel("Length:");
		lblcm.setFont(new Font("����", Font.BOLD, 16));
		lblcm.setBounds(108, 43, 65, 23);
		panel.add(lblcm);
		
		JLabel lblNewLabel = new JLabel("Width:");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 16));
		lblNewLabel.setBounds(108, 102, 58, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Speed:");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 16));
		lblNewLabel_1.setBounds(108, 155, 58, 15);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Length = Integer.parseInt(textLength.getText());
				Width = Integer.parseInt(textWidth.getText());
				Speed = Integer.parseInt(textSpeed.getText());
				System.out.println(Length+" "+Width+" "+Speed);
				if(Length>0&&Width>0&&Speed>0) {
					GameUI gameUI = new GameUI(Length, Width,Speed);
					dispose();
				}else
					JOptionPane.showMessageDialog(null, "���벻�Ϸ�","��ʾ��",JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		btnNewButton.setFont(new Font("����", Font.BOLD, 16));
		btnNewButton.setBounds(161, 207, 97, 23);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("\u53C2\u8003\u503C");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 16));
		lblNewLabel_2.setBounds(304, 10, 58, 25);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("  30");
		lblNewLabel_3.setFont(new Font("����", Font.BOLD, 16));
		lblNewLabel_3.setBounds(304, 48, 58, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("  30");
		lblNewLabel_4.setFont(new Font("����", Font.BOLD, 16));
		lblNewLabel_4.setBounds(304, 102, 58, 15);
		panel.add(lblNewLabel_4);
		
		JLabel label = new JLabel("  800");
		label.setFont(new Font("����", Font.BOLD, 16));
		label.setBounds(304, 155, 58, 15);
		panel.add(label);
	}
}
