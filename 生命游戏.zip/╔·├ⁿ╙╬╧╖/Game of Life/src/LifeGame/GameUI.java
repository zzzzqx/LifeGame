package LifeGame;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Stack;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GameUI extends JFrame{
	
	
	private JPanel panel_1;
	//������
	private int Length;
	private int Width;
	//��ʾϸ��״̬
	private static JPanel[][] jPanels;
	//�����ٶ�
	private int Speed;
	//��ɫ״̬
	public final static Color Live = new Color(135,206,235);
	public final static Color Death = new Color(245,245,245);
	public final static Color Border = new Color(255,255,255);
	//ϸ����Service��
	Cell cell;
	
	JFrame iFrame;
	
	
	
	//��ʼ��GUI����
	public GameUI(int length,int width,int speed) {
		this.Length = length;
		this.Width = width;
		this.Speed = speed;
		
		iFrame = new JFrame("Game of Life");
		
		jPanels = new JPanel[length][width];
		iFrame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		iFrame.getContentPane().add(panel,BorderLayout.NORTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER,5,5));
		
		panel_1 = new JPanel();
		iFrame.getContentPane().add(panel_1,BorderLayout.CENTER);
		panel_1.setLayout(new GridLayout(Length,Width));
		
		for(int i=0;i<length;i++) {
			for(int j=0;j<width;j++) {
				jPanels[i][j] = new JPanel();
				jPanels[i][j].setBackground(Death);
				jPanels[i][j].setBorder(BorderFactory.createLineBorder(Border,1));
				panel_1.add(jPanels[i][j]);
			}
		}
		
		iFrame.setLocation(450, 180);
		iFrame.setSize(600,600);
		
		
		iFrame.setVisible(true);
		//��ʼ��ϸ����
		cell = new Cell(Length,Width);
		cell.Creat();
		//��ʼ����
		new TransformThread().start();
	}
	
	public void SetColor() {
		for(int i=0;i<cell.RoomLength;i++) {
			for(int j=0;j<cell.RoomWidth;j++) {
				if(cell.CellRoom[i][j])
					jPanels[i][j].setBackground(Live);
				else 
					jPanels[i][j].setBackground(Death);
			}
		}
	}
	
	public class TransformThread extends Thread {
		public void run() {
			while(true) {
				try {
					Thread.sleep(Speed);
					cell.transform();
					SetColor();
				
			}catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}
	}
	
	public static void main(String[] args) {
		GameUI gameUI = new GameUI(20, 20,800);
		
		
	}
}



